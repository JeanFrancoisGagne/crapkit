"""Save the bounded fixture repair's source and execution receipts."""
import hashlib
import importlib.metadata
import json
import platform
import shutil
import subprocess
import sys
from pathlib import Path
from xml.etree import ElementTree

import crapkit


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def cases(path):
    root = ElementTree.parse(path).getroot()
    return [{"id": case.get("classname") + "::" + case.get("name"),
             "seconds": float(case.get("time", 0)),
             "failed": case.find("failure") is not None,
             "error": case.find("error") is not None,
             "skipped": case.find("skipped") is not None}
            for case in root.iter("testcase")]


evidence = Path(__file__).resolve().parent
checkout = Path.cwd()
assert Path(crapkit.__file__).resolve() == checkout / "src/crapkit/__init__.py"
test = checkout / "tests/unit/test_init_probe.py"
before = (evidence / "before.py").read_text(encoding="utf-8")
red = before.replace("def _long_sleeper(tmp_path) -> tuple:",
                     "def _long_sleeper(tmp_path, startup_delay=0) -> tuple:")
red = red.replace('script.write_text("import pathlib, time\\n"\n',
                  'script.write_text("import pathlib, time\\n"\n'
                  '                      f"time.sleep({startup_delay})\\n"\n')
red = red.replace(
    "def test_the_probe_kills_the_interpreter_it_stopped_waiting_for(tmp_path, monkeypatch):",
    '@pytest.mark.parametrize("startup_delay", [0, _TIMEOUT + 1], ids=["ready", "delayed"])\n'
    "def test_the_probe_kills_the_interpreter_it_stopped_waiting_for(tmp_path, monkeypatch, startup_delay):")
prefix, target = red.split("def test_the_probe_kills_the_interpreter_it_stopped_waiting_for", 1)
red = prefix + "def test_the_probe_kills_the_interpreter_it_stopped_waiting_for" + target.replace(
    "command, token, started = _long_sleeper(tmp_path)",
    "command, token, started = _long_sleeper(tmp_path, startup_delay)", 1)
(evidence / "red-test.py").write_text(red, encoding="utf-8")
shutil.copyfile(test, evidence / "green-test.py")
for stage in ("red", "green", "posix"):
    shutil.copyfile(checkout / f".crapkit/probe-readiness-{stage}.coverage",
                    evidence / f"{stage}.coverage")
source_names = subprocess.check_output(["git", "ls-files", "src"], text=True).splitlines()
result = {
    "base_commit": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
    "checkout": str(checkout), "python": sys.executable, "version": platform.python_version(),
    "platform": platform.platform(), "import": crapkit.__file__,
    "dependencies": {name: importlib.metadata.version(name) for name in
                     ("pytest", "pytest-cov", "pytest-xdist", "coverage", "lizard")},
    "changed_files": subprocess.check_output(["git", "diff", "--cached", "--name-only"], text=True).splitlines(),
    "red": cases(evidence / "red.xml"), "green": cases(evidence / "green.xml"),
    "posix": cases(evidence / "posix.xml"),
    "posix_import": (evidence / "posix-import.txt").read_text(encoding="utf-8").splitlines(),
    "hook": {"command": "python -m crapkit hook-precommit", "exit_code": 0},
    "changed_function_ccn": {"_long_sleeper": 1, "_probe_timeout_after_start.wait": 4,
                             "_probe_timeout_after_start": 1,
                             "test_the_probe_kills_the_interpreter_it_stopped_waiting_for": 1},
    "source_sha256": {name: digest(checkout / name) for name in source_names},
    "evidence_sha256": {name: digest(evidence / name) for name in (
        "before.py", "red-test.py", "green-test.py", "red.log", "red.xml", "red.coverage",
        "green.log", "green.xml", "green.coverage", "posix.log", "posix.xml", "posix.coverage",
        "probe-readiness.patch", "precommit.log")},
    "limits": ["Windows and POSIX focused checks only; the root owns full integration runs.",
               "The three-second startup delay is synthetic and tests the setup race.",
               "The cleanup fixture waits for readiness before the unchanged two-second deadline.",
               "The separate unwrapped probe deadline case still checks the five-second wall limit.",
               "No production code, deadline constants, thresholds, or main artifacts changed."]}
(evidence / "result.json").write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
print(json.dumps({"red_cases": len(result["red"]), "green_cases": len(result["green"]),
                  "posix_cases": len(result["posix"]),
                  "changed_files": result["changed_files"], "patch_sha256":
                  result["evidence_sha256"]["probe-readiness.patch"]}, indent=2))
