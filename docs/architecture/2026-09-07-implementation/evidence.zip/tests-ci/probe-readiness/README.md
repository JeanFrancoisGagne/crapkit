# Probe cleanup fixture readiness

The fixture repair passed the same five focused cases on Windows and POSIX under
branch and subprocess coverage. Only `tests/unit/test_init_probe.py` changed. Production source,
timeouts, thresholds, main checkout and its active artifacts stayed unchanged.

Base: `0009a6776f7e260046589954d98e035918f89439`.
Isolated checkout: `C:/Users/jfgag/Documents/Codex/worktrees/ck-r2-probe-readiness`.

## Cause and repair

The first full run failed before its cleanup assertion: the interpreter had not
created its `.started` marker when the probe's two-second timeout killed the
launch. The fixture used interpreter startup speed as a prerequisite for a
descendant cleanup assertion. Startup can exceed that deadline under loaded
subprocess coverage.

The new `delayed` case sleeps three seconds before writing the marker. With no
handshake it fails at the same missing-marker assertion (`red.log`, one failure).
The test now waits for that marker at `procs._wait_command`, confirms the launcher
is live, then calls the original adapter with the same timeout of two seconds.
It records and re-raises the real `TimeoutExpired`, and checks that record after
the probe. Both original started/gone assertions remain.

The readiness guard uses the existing 30-second sleeper lifetime as its setup
bound. It does not change `_TIMEOUT`, `_CEILING`, `_ORPHAN_SLEEP`, or
`_ORPHAN_POLL`. The separate unwrapped probe deadline test still checks the real
two-second deadline against its existing five-second wall limit.

## Evidence

| Check | Result | Evidence |
| --- | --- | --- |
| Synthetic delayed startup before repair | One expected failure at missing marker | `red.log`, `red.xml`, `red.coverage`, `red-test.py` |
| Windows ready/delayed probe cleanup and existing deadline/tree family | Five passed, 24.39 seconds | `green.log`, `green.xml`, `green.coverage`, `green-test.py` |
| POSIX same five cases and assertions | Five passed, 21.41 seconds | `posix.log`, `posix.xml`, `posix.coverage`, `posix-import.txt` |
| Staged hook | Exit 0 | `precommit.log`, `result.json` |
| Changed-function CCN | Maximum 4 | `complexity.txt` |
| Independent execution review | No findings | Review conclusion below |

The first command used an invalid PowerShell spelling for `--junitxml` and ran
zero tests. `red-setup-error.log` retains that setup error. `red.log` is the
corrected invocation and the actual behavioral failure.

`result.json` records source and artifact hashes, exact test IDs, interpreter,
dependency versions, changed paths, and limits. The staged incremental patch is
`probe-readiness.patch`; SHA-256:
`eae3a4e6a1668619774c903d4d4e259791564bb7fa1b27cb624050de5717e83c`.

The independent reviewer checked the final helper against production deadline
handling: it waits only during fixture setup, preserves the finite timeout,
records the actual exception, and leaves the unwrapped wall-clock tests intact.

## Replay

Use a disposable checkout at the recorded base. Copy `red-test.py` to its
`tests/unit/test_init_probe.py`, then run the delayed selector below. Copy
`green-test.py` over that file and run all four selectors below (five cases).
Do not replace the main checkout's file while a source run is active.

```powershell
$checkout = 'C:\Users\jfgag\Documents\Codex\worktrees\ck-r2-probe-readiness'
$evidence = 'C:\Users\jfgag\Documents\Codex\2026-09-06\c-users-jfgag-appdata-local-temp\work\implementation-round2\tests-ci\probe-readiness'
$py = 'C:\Users\jfgag\Documents\Codex\2026-09-06\c-users-jfgag-appdata-local-temp\work\implementation\configured-runtime\venv\Scripts\python.exe'
Set-Location $checkout
$env:PYTHONPATH = "$checkout\src"
$env:PATH = (Split-Path $py) + [IO.Path]::PathSeparator + $env:PATH
& $py -c 'import crapkit; print(crapkit.__file__)'
$env:COVERAGE_FILE = '.crapkit/probe-readiness-replay.coverage'

# Red selector, with red-test.py installed in the disposable checkout:
& $py -m pytest 'tests/unit/test_init_probe.py::test_the_probe_kills_the_interpreter_it_stopped_waiting_for[delayed]' --cov=crapkit --cov-branch --cov-context=test --cov-report= "--junitxml=$evidence\replay-red.xml"

# Green selectors, with green-test.py installed in that checkout:
& $py -m pytest tests/unit/test_init_probe.py::test_the_probe_kills_the_interpreter_it_stopped_waiting_for tests/unit/test_init_probe.py::test_the_probe_gives_up_when_its_timeout_expires tests/unit/test_init_probe.py::test_a_mutant_that_outlives_its_timeout_dies_at_the_timeout tests/unit/test_init_probe.py::test_a_timed_out_mutant_takes_its_whole_process_tree_with_it --cov=crapkit --cov-branch --cov-context=test --cov-report= "--junitxml=$evidence\replay-green.xml"
```

`posix-check.sh` replays the identical five cases in the managed WSL Python 3.11.16
environment. Windows used the configured Python 3.11.2 environment. Both selected
the isolated checkout's source, and both retained branch and subprocess coverage.

This is a fixture correctness repair. No performance gain is claimed. No broad
suite was run for this follow-up; full integration remains with the main
verification run.
