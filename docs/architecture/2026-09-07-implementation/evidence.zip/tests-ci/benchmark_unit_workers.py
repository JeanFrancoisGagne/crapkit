"""Compare one fixed mixed unit selection with complete branch and JUnit evidence."""
import json
import os
from pathlib import Path
import statistics
import subprocess
import sys
import time
import xml.etree.ElementTree as ET

import crapkit

REPO = Path(r"C:\Users\jfgag\Documents\Codex\worktrees\ck-r2-tests-ci")
SCRATCH = Path(__file__).resolve().parent / "unit-workers-short"
assert Path(crapkit.__file__).resolve() == REPO / "src/crapkit/__init__.py"
SCRATCH.mkdir(exist_ok=True)
SELECTION = [
    "tests/unit/test_release_recovery.py::test_failure_after_each_publication_resumes_without_republishing[push]",
    "tests/unit/test_release_recovery.py::test_failure_after_each_publication_resumes_without_republishing[github:create]",
    "tests/unit/test_release_recovery.py::test_failure_after_each_publication_resumes_without_republishing[pages]",
    "tests/unit/test_cli_verifying_inproc.py::test_naming_the_baseline_run_by_id_accepts_it",
    "tests/unit/test_cli_verifying_inproc.py::test_a_baseline_written_out_reads_back_in",
    "tests/unit/test_suite_schedule.py::test_real_runner_keeps_both_suites_and_subprocess_branches[no-contexts]",
    "tests/unit/test_cache.py",
    "tests/unit/test_score.py",
]


def run(workers, sample):
    label = f"{sample}-workers{workers}"
    folder = SCRATCH / label
    folder.mkdir()
    command = [sys.executable, "-m", "pytest", *SELECTION, "-p", "no:randomly",
               "--basetemp=" + str(REPO / ".crapkit" / ("uw-" + label)), "--junitxml=" + str(folder / "junit.xml"),
               "--cov=crapkit", "--cov-branch", "--cov-report=json:" + str(folder / "coverage.json")]
    if workers > 1:
        command += ["-n", str(workers)]
    environment = dict(os.environ, COVERAGE_FILE=str(folder / ".coverage"))
    environment["PATH"] = str(Path(sys.executable).parent) + os.pathsep + environment["PATH"]
    before = time.perf_counter()
    with (folder / "pytest.log").open("w", encoding="utf-8") as output:
        result = subprocess.run(command, cwd=REPO, env=environment, stdout=output, stderr=subprocess.STDOUT)
    seconds = time.perf_counter() - before
    report = ET.parse(folder / "junit.xml")
    nodes = sorted((case.attrib.get("classname"), case.attrib["name"]) for case in report.findall(".//testcase"))
    assert not report.findall(".//failure") and not report.findall(".//error"), label
    assert result.returncode == 0, label
    coverage = json.loads((folder / "coverage.json").read_text())
    lines = {path: data["executed_lines"] for path, data in coverage["files"].items()}
    branches = {path: data["executed_branches"] for path, data in coverage["files"].items()}
    print(label, round(seconds, 3), len(nodes), flush=True)
    return {"seconds": seconds, "nodes": nodes, "lines": lines, "branches": branches,
            "command": command, "exit": result.returncode}


results = {"import": str(crapkit.__file__), "cold": {}, "warm": {str(n): [] for n in (1, 2, 4)}}
for workers in (1, 2, 4):
    results["cold"][str(workers)] = run(workers, "cold")
    (SCRATCH / "results.json").write_text(json.dumps(results, indent=2) + "\n")
for sample in range(5):
    order = (1, 2, 4) if sample % 2 == 0 else (4, 2, 1)
    for workers in order:
        results["warm"][str(workers)].append(run(workers, "warm" + str(sample)))
        (SCRATCH / "results.json").write_text(json.dumps(results, indent=2) + "\n")
results["medians"] = {n: statistics.median(item["seconds"] for item in rows)
                      for n, rows in results["warm"].items()}
(SCRATCH / "results.json").write_text(json.dumps(results, indent=2) + "\n")
print(json.dumps(results["medians"], indent=2))
