"""Compare the same pristine release input before and after fixture reuse."""
import gc
import importlib.util
import json
from pathlib import Path
import statistics
import sys
import tempfile
import time

import crapkit

REPO = Path(r"C:\Users\jfgag\Documents\Codex\worktrees\ck-r2-tests-ci")
SCRATCH = Path(__file__).resolve().parent
assert Path(crapkit.__file__).resolve() == REPO / "src/crapkit/__init__.py"
sys.path.insert(0, str(REPO / "tests/unit"))


def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result


def measured(factory, folder):
    before = time.perf_counter()
    root = factory.repo(folder, bumped=True)
    elapsed = time.perf_counter() - before
    assert factory.git(root, "status", "--porcelain") == ""
    assert factory.git(root, "branch", "--show-current") == "main"
    head = factory.git(root, "rev-parse", "HEAD")
    assert factory.git(root, "ls-remote", "origin", "refs/heads/main").split()[0] == head
    source = (root / "src/crapkit/__init__.py").read_text()
    assert '__version__ = "0.5.2"' in source
    assert not (root / ".crapkit").exists()
    return elapsed


factories = {
    "base": module("fixture_base", SCRATCH / "release_guards.before.py"),
    "candidate": module("fixture_candidate", REPO / "tests/unit/test_release_guards.py"),
}
results = {"import": str(crapkit.__file__), "cold": {}, "warm": {key: [] for key in factories}}
with tempfile.TemporaryDirectory(prefix="fixture-pair-", dir=SCRATCH) as directory:
    parent = Path(directory)
    for key, factory in factories.items():
        results["cold"][key] = measured(factory, parent / key / "cold")
    for sample in range(7):
        order = ("base", "candidate") if sample % 2 == 0 else ("candidate", "base")
        for key in order:
            results["warm"][key].append(measured(factories[key], parent / key / str(sample)))
    gc.collect()
results["medians"] = {key: statistics.median(values) for key, values in results["warm"].items()}
results["limits"] = "Windows 3.11.2, fixture setup only, uninstrumented, same-host interleaved samples; production release admission remains unchanged."
(SCRATCH / "fixture-timings.json").write_text(json.dumps(results, indent=2) + "\n")
print(json.dumps(results, indent=2))
