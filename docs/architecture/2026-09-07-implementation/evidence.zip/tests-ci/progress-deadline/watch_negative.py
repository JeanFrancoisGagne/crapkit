"""Deliberately break one watch rule per selected test, without source edits."""
from crapkit import procs


def pytest_runtest_call(item):
    patch = item._request.getfixturevalue("monkeypatch")
    if item.name == "test_a_command_that_keeps_writing_outlives_the_progress_deadline":
        patch.setattr(procs, "_progress", lambda stream, size, since:
                      (procs._stream_size(stream), since))
    elif item.name == "test_the_total_deadline_still_kills_a_watched_command_that_keeps_writing":
        patch.setattr(procs, "_expired", lambda limit: False)
