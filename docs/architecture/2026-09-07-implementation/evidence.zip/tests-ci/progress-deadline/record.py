"""Record focused deadline-fixture evidence without invoking any test suite."""
import hashlib
import importlib.metadata
import json
import platform
import shutil
import subprocess
import sys
from pathlib import Path
from xml.etree import ElementTree

import crapkit


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def cases(path):
    return [{"id": item.get("classname") + "::" + item.get("name"),
             "seconds": float(item.get("time", 0)),
             "failed": item.find("failure") is not None,
             "error": item.find("error") is not None,
             "skipped": item.find("skipped") is not None}
            for item in ElementTree.parse(path).getroot().iter("testcase")]


evidence = Path(__file__).resolve().parent
checkout = Path.cwd()
assert Path(crapkit.__file__).resolve() == checkout / "src/crapkit/__init__.py"
names = ["tests/unit/test_procs.py", "tests/unit/test_init_probe.py"]
for name in names:
    shutil.copyfile(checkout / name, evidence / ("green-" + Path(name).name))
    original = subprocess.check_output(["git", "show", "HEAD:" + name])
    (evidence / ("before-" + Path(name).name)).write_bytes(original)
for name in ("red", "family-red", "green", "posix", "watch-negative"):
    shutil.copyfile(checkout / f".crapkit/progress-deadline-{name}.coverage",
                    evidence / f"{name}.coverage")
coverage = json.loads((evidence / "green-coverage.json").read_text())
measured = next(data for name, data in coverage["files"].items()
                if name.replace("\\", "/").endswith("/crapkit/procs.py"))
functions = {name: data for name, data in measured["functions"].items()
             if name in {"_progress", "_expired", "_wait_watching", "_wait_bounded"}}
rows = {name: cases(evidence / f"{name}.xml")
        for name in ("red", "family-red", "green", "posix", "watch-negative")}
assert [row["id"] for row in rows["green"]] == [row["id"] for row in rows["posix"]]
sources = subprocess.check_output(["git", "ls-files", "src"], text=True).splitlines()
result = {
    "base_commit": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
    "checkout": str(checkout), "python": sys.executable,
    "platform": platform.platform(), "version": platform.python_version(), "import": crapkit.__file__,
    "dependencies": {name: importlib.metadata.version(name) for name in
                     ("pytest", "pytest-cov", "pytest-xdist", "coverage", "lizard")},
    "posix_import": (evidence / "posix-import.txt").read_text().splitlines(),
    "changed_files": subprocess.check_output(["git", "diff", "--cached", "--name-only"], text=True).splitlines(),
    "runs": rows, "windows_posix_ids_equal": True,
    "hook": {"command": "python -m crapkit hook-precommit", "exit_code": 0},
    "complexity": json.loads((evidence / "complexity.json").read_text(encoding="utf-8-sig")),
    "watcher_coverage": functions,
    "source_sha256": {name: digest(checkout / name) for name in sources},
    "patch_sha256": digest(evidence / "progress-deadline.patch"),
    "evidence_sha256": {file.name: digest(file) for file in evidence.iterdir()
                        if file.is_file() and file.suffix in {".xml", ".log", ".coverage"}},
    "limits": ["Focused Windows and POSIX checks; full integration remains with root.",
               "Readiness removes setup time from cleanup ceilings; unwrapped wall-clock controls remain.",
               "Synthetic startup delay is three seconds; unchanged total deadline is two seconds.",
               "Watcher arithmetic uses a module-local controlled clock and real file growth.",
               "The negative plugin deliberately breaks two rules and imports Crapkit before coverage; its warning is retained.",
               "No production source, timeout constants, thresholds, or main artifacts changed."]}
(evidence / "result.json").write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
print(json.dumps({"cases": {name: len(items) for name, items in rows.items()},
                  "watcher_summary": {name: item["summary"] for name, item in functions.items()},
                  "patch_sha256": result["patch_sha256"]}, indent=2))
