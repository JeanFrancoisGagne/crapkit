"""Run the unchanged public release retry case with old and new fixture setup."""
import gc
import importlib.util
import json
from pathlib import Path
import statistics
import sys
import tempfile
import time

import crapkit
import pytest

REPO = Path(r"C:\Users\jfgag\Documents\Codex\worktrees\ck-r2-tests-ci")
SCRATCH = Path(__file__).resolve().parent
assert Path(crapkit.__file__).resolve() == REPO / "src/crapkit/__init__.py"
sys.path.insert(0, str(REPO / "tests/unit"))
import test_release_guards as current
import test_release_recovery as recovery

spec = importlib.util.spec_from_file_location("old_guards", SCRATCH / "release_guards.before.py")
old = importlib.util.module_from_spec(spec)
spec.loader.exec_module(old)


def measured(factory, directory):
    before = time.perf_counter()
    with pytest.MonkeyPatch.context() as patch:
        patch.setattr(recovery, "repo", factory.repo)
        recovery.test_failure_after_each_publication_resumes_without_republishing(directory, patch, "push")
    return time.perf_counter() - before


factories = {"base": old, "candidate": current}
results = {"import": str(crapkit.__file__), "cold": {}, "warm": {key: [] for key in factories},
           "case": "test_failure_after_each_publication_resumes_without_republishing[push]"}
with tempfile.TemporaryDirectory(prefix="retry-pair-", dir=SCRATCH) as directory:
    parent = Path(directory)
    for key, factory in factories.items():
        results["cold"][key] = measured(factory, parent / key / "cold")
    for sample in range(5):
        order = ("base", "candidate") if sample % 2 == 0 else ("candidate", "base")
        for key in order:
            results["warm"][key].append(measured(factories[key], parent / key / str(sample)))
    gc.collect()
results["medians"] = {key: statistics.median(values) for key, values in results["warm"].items()}
results["limits"] = "Windows 3.11.2; unchanged existing test body invoked directly with MonkeyPatch; real Git/local remote writes and production release guards, fake network/build adapter; no pytest/coverage startup in timed region."
(SCRATCH / "retry-timings.json").write_text(json.dumps(results, indent=2) + "\n")
print(json.dumps(results, indent=2))
