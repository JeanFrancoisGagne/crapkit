"""Measure independent mini repositories with old and new preparation."""
import importlib.util
import json
from pathlib import Path
import statistics
import sys
import tempfile
import time

import crapkit

REPO = Path(r"C:\Users\jfgag\Documents\Codex\worktrees\ck-r2-tests-ci")
SCRATCH = Path(__file__).resolve().parent
assert Path(crapkit.__file__).resolve() == REPO / "src/crapkit/__init__.py"
sys.path.insert(0, str(REPO / "tests/e2e"))


def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(spec)
    sys.modules[name] = result
    spec.loader.exec_module(result)
    result.FIXTURES = REPO / "tests/fixtures"
    return result


def measured(factory, path):
    before = time.perf_counter()
    root = factory.mini_repo.__wrapped__(path)
    elapsed = time.perf_counter() - before
    assert (root / "src/app.ts").read_bytes() == (REPO / "tests/fixtures/mini_repo/src/app.ts").read_bytes()
    assert not (root / ".crapkit").exists()
    return elapsed


factories = {"base": module("inventory_base", SCRATCH / "inventory.before.py"),
             "candidate": module("inventory_candidate", REPO / "tests/e2e/test_inventory_e2e.py")}
result = {"import": str(crapkit.__file__), "cold": {}, "warm": {key: [] for key in factories}}
with tempfile.TemporaryDirectory(prefix="inventory-pair-", dir=SCRATCH) as directory:
    parent = Path(directory)
    for key, factory in factories.items():
        result["cold"][key] = measured(factory, parent / key / "cold")
    for sample in range(7):
        order = ("base", "candidate") if sample % 2 == 0 else ("candidate", "base")
        for key in order:
            result["warm"][key].append(measured(factories[key], parent / key / str(sample)))
result["medians"] = {key: statistics.median(values) for key, values in result["warm"].items()}
result["limits"] = "Windows 3.11.2; fixture setup only, no CLI or lane time; pytest-xdist creates a seed per worker."
(SCRATCH / "inventory-timings.json").write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps(result, indent=2))
