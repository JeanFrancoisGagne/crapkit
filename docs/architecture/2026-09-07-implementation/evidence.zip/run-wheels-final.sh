#!/bin/sh
set -u
REPO=/mnt/c/Users/jfgag/crapkit
EVIDENCE=/mnt/c/Users/jfgag/Documents/Codex/2026-09-06/c-users-jfgag-appdata-local-temp/work/implementation-round2
PYTHON=/tmp/ck-r2-tests-ci-runtime-20260907/venv/bin/python
cd "$REPO" || exit 1
"$PYTHON" tools/testing/ci.py --repo "$REPO" --base c2d3515581d410d8c14849063dac27af843a3729 --output "$EVIDENCE/wheels-final" > "$EVIDENCE/full-wheels-final.log" 2>&1
result=$?
printf '%s\n' "$result" > "$EVIDENCE/full-wheels-final.exit"
exit "$result"
