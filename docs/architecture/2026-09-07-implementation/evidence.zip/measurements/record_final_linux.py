"""Index a reconciled passing Linux attempt while Windows remains pending."""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
REPO = Path("C:/Users/jfgag/crapkit")


def read(name):
    return json.loads((ROOT / name).read_text(encoding="utf-8-sig"))


def save(name, value):
    (ROOT / name).write_text(json.dumps(value, indent=2) + "\n", encoding="utf-8")


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


proof = read("final-wheel-proof.json")
matrix = read("completion-matrix.json")
assert proof["candidate_commit"] == matrix["implementation_commit"]
assert proof["candidate_ok"] and proof["process_exit"] == proof["suite_exits"][1] == 0
assert matrix["integration_verification"]["windows_full_source_verify"]["status"] == "pending"
verification = matrix["integration_verification"]
verification["linux_installed_wheel_base_candidate"].update(
    status="passed", note="The current candidate's complete Linux wheel comparison passed; Windows remains pending.",
    final_attempt=proof)
verification["final_artifacts"].update(
    linux_wheels_status="passed", windows_source_status="pending", status="pending",
    note=f"{proof['candidate_commit'][:8]} Linux wheels passed and the saved ledger agrees; Windows source remains pending. Production bytes equal 0082379.")
for row in matrix["candidates"] + matrix["extra_work"]:
    row["complete_suite_platforms"]["linux_installed_wheels"] = "passed"
save("completion-matrix.json", matrix)

integration = read("integration-review.json")
integration["status"] = "Implementation, fixture and packaging reviews complete; current Linux passed and Windows remains pending."
integration["current_verification"].update(commit=proof["candidate_commit"], linux="passed", windows="pending",
                                          linux_proof="final-wheel-proof.json")
integration["pending"] = ["Complete the current Windows source run, reconcile its saved ledger and cross-host coverage, then admit final report metadata and package matching passing results."]
save("integration-review.json", integration)

manifest = read("evidence-manifest.json")
refresh = {"coverage-disposition.json", "integration-review.json", "measurements/reconcile_final_wheel.py", "measurements/record_final_linux.py", "decisions.tsv"}
for entry in manifest["entries"]:
    path = REPO / entry["path"][5:] if entry["path"].startswith("repo:") else ROOT / entry["path"]
    if entry["path"] not in refresh:
        assert digest(path) == entry["sha256"], f"Preserved evidence changed: {entry['path']}"


def include(name, kind, purpose):
    path = ROOT / name
    entry = dict(path=name, candidates=["ALL"], kind=kind, purpose=purpose,
                 bytes=path.stat().st_size, sha256=digest(path))
    manifest["entries"] = [item for item in manifest["entries"] if item["path"] != name] + [entry]


for name in ("unit.xml", "e2e.xml", "junit.xml"):
    for revision in ("base", "candidate"):
        include(f"{proof['attempt']}/{revision}/cov/{name}", "complete Linux wheel JUnit",
                "Current noneditable wheel comparison; candidate passes and actual historical base failures remain recorded")
for name in ("wheels-final/verdict.json", "full-wheels-final.log", "full-wheels-final.exit"):
    include(name, "complete Linux wheel result", f"{proof['candidate_commit'][:8]} comparison passed; saved candidate ledger has verdict_ok=1 and findings=0")
include("final-wheel-proof.json", "complete Linux wheel proof", "Full JUnit counts, saved ledger, exact Git source identity and compact coverage facts")
include("coverage-disposition.json", "coverage disposition", "Current Linux gaps plus preserved prior cross-host evidence; Windows current run pending")
include("integration-review.json", "independent integration review", "Implementation reviews complete; current Linux passed and Windows remains pending")
include("measurements/reconcile_final_wheel.py", "replay", "Read-only JUnit, ledger and canonical source proof; count actual base failures")
include("measurements/record_final_linux.py", "replay", "Index final Linux evidence while retaining pending Windows and historical attempt paths")
if any(item["path"] == "decisions.tsv" for item in manifest["entries"]):
    include("decisions.tsv", "decision log", "Root-owned implementation and verification chronology; refresh after later append")
manifest.update(integration_verification=f"{proof['candidate_commit'][:8]} Linux wheels passed. Windows source remains pending. Earlier passing and refusing attempts remain preserved.")
manifest["curation"]["included"] = "Focused red/green logs and JUnit, owner results, compact summaries, repeatable probes, immutable duplication input, all preserved prior attempts, passing current Linux JUnit/provenance, and reviewed fixture repairs."
manifest["curation"]["excluded"][-1] = "Active Windows source artifacts require the final result."
manifest["entries"].sort(key=lambda item: item["path"])
manifest["curation"]["file_count"] = len(manifest["entries"])
manifest["curation"]["total_bytes"] = sum(item["bytes"] for item in manifest["entries"])
save("evidence-manifest.json", manifest)
print(json.dumps(dict(commit=proof["candidate_commit"], linux="passed", windows="pending",
                      entries=manifest["curation"]["file_count"], bytes=manifest["curation"]["total_bytes"])))
