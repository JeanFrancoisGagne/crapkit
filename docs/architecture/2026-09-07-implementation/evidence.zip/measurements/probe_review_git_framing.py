"""Check whether inherited Git display options can change gate attribution."""
import json
import os
from pathlib import Path
import subprocess
import tempfile

from crapkit.config import load_config_text
from crapkit.diffparse import changed_ranges
from crapkit.gitio import diff_since, staged_diff, staged_reads
from crapkit.hook import gate_staged

HERE = Path(__file__).resolve().parent
root = Path(tempfile.mkdtemp(prefix="review-git-framing-", dir=HERE))
(root / "src").mkdir(exist_ok=True)


def git(*args):
    return subprocess.check_output(["git", "-c", "user.name=Review", "-c", "user.email=review@example.invalid", *args], cwd=root)


source = "def old_debt(x):\n" + "".join(f"    if x == {i}: return {i}\n" for i in range(7)) + "    return 0\n\ndef clean():\n    return 1\n"
path = root / "src/app.py"
path.write_text(source, encoding="utf-8")
git("init", "-q")
git("add", "src/app.py")
git("commit", "-qm", "unchanged accepted debt and a clean function")
path.write_text(source.replace("    return 1\n", "    return 2\n"), encoding="utf-8")
git("add", "src/app.py")
cfg = load_config_text('[crapkit]\ntarget=6\n[[scope]]\nname="src"\npaths=["src"]\nlanguages=["python"]\ncoverage_optional=true\n')
result = {}
for key, value in [("control", None), ("inherited_display_context", "--unified=20")]:
    if value is None:
        os.environ.pop("GIT_DIFF_OPTS", None)
    else:
        os.environ["GIT_DIFF_OPTS"] = value
    plain = gate_staged(root, cfg)
    with staged_reads(root) as reads:
        started = gate_staged(root, cfg, reads)
    result[key] = {"environment": value, "staged_ranges": changed_ranges(staged_diff(root)),
                   "since_ranges": changed_ranges(diff_since(root, "HEAD")),
                   "gate_violations": [[v.path, v.long_name, v.ccn] for v in plain.violations],
                   "prestarted_violations": [[v.path, v.long_name, v.ccn] for v in started.violations]}
(HERE / "review-git-framing-result.json").write_text(json.dumps(result, indent=2), encoding="utf-8")
print(json.dumps(result, indent=2))
