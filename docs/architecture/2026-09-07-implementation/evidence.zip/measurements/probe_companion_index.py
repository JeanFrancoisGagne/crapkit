"""Replay pending refusal and complete companion indexing in private directories."""
import copy
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import tempfile

ROOT = Path(__file__).resolve().parents[1]
OUTPUT = ROOT / "measurements/manifest-finalizer"
baseline = json.loads((ROOT / "completion-matrix.json").read_text(encoding="utf-8-sig"))
COMMIT = "a" * 40
baseline.update(implementation_commit=COMMIT, final_verified_commit=COMMIT)
state = baseline["integration_verification"]
state["windows_full_source_verify"]["status"] = state["linux_installed_wheel_base_candidate"]["status"] = "passed"
state["final_artifacts"].update(commit=COMMIT, status="complete", windows_source_status="passed", linux_wheels_status="passed")
for row in baseline["candidates"] + baseline["extra_work"]:
    row.update(implemented=True, complete_suite_status="passed",
               complete_suite_platforms=dict(linux_installed_wheels="passed", windows_source="passed"))
results = []
with tempfile.TemporaryDirectory(prefix="index-", dir=OUTPUT) as temporary:
    for complete in (False, True):
        case = Path(temporary) / str(complete)
        case.mkdir()
        matrix = copy.deepcopy(baseline)
        if not complete:
            matrix["final_verified_commit"] = None
        (case / "completion-matrix.json").write_text(json.dumps(matrix), encoding="utf-8")
        (case / "report-draft.md").write_text("Measured report\n", encoding="utf-8")
        (case / "decisions.tsv").write_text("date\tdecision\n", encoding="utf-8")
        manifest_path = case / "evidence-manifest.json"
        manifest_path.write_text(json.dumps(dict(implementation_commit=COMMIT, entries=[], curation={})), encoding="utf-8")
        before = manifest_path.read_bytes()
        command = [sys.executable, str(ROOT / "add_report_companions.py"), str(case), str(case)]
        run = subprocess.run(command, capture_output=True, text=True)
        result = dict(complete=complete, exit=run.returncode)
        if complete:
            manifest = json.loads(manifest_path.read_text())
            paths = {entry["path"] for entry in manifest["entries"]}
            hashes_match = all(hashlib.sha256((case / item["path"]).read_bytes()).hexdigest() == item["sha256"] for item in manifest["entries"])
            first = manifest_path.read_bytes()
            replay = subprocess.run(command, capture_output=True, text=True)
            result.update(paths=sorted(paths), hashes_match=hashes_match, replay_exit=replay.returncode,
                          idempotent=first == manifest_path.read_bytes())
            result["passed"] = (run.returncode == replay.returncode == 0 and hashes_match and result["idempotent"]
                                and paths == {"report-draft.md", "completion-matrix.json", "decisions.tsv"})
        else:
            result["manifest_unchanged"] = manifest_path.read_bytes() == before
            result["passed"] = run.returncode == 1 and result["manifest_unchanged"]
        results.append(result)
receipt = dict(method="Invoke the real companion-index script on private pending and complete metadata; verify exact companion hashes and idempotent replay.",
               cases=results, passed=sum(item["passed"] for item in results))
(OUTPUT / "index-replay.json").write_text(json.dumps(receipt, indent=2) + "\n", encoding="utf-8")
assert receipt["passed"] == 2
print(json.dumps(receipt))
