"""Exercise packaging admission with synthetic metadata and private output files."""
import contextlib
import copy
import hashlib
import importlib.util
import io
import json
from pathlib import Path
import sys
import tempfile

ROOT = Path(__file__).resolve().parents[1]
OUTPUT = ROOT / "measurements/manifest-finalizer"
MEASURED = "a" * 40
FINALIZER = Path(sys.argv[2]) if len(sys.argv) > 2 else ROOT / "finalize_evidence.py"
spec = importlib.util.spec_from_file_location("reviewed_finalizer", FINALIZER)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
original = json.loads((ROOT / "completion-matrix.json").read_text(encoding="utf-8-sig"))
baseline = copy.deepcopy(original)
baseline.update(implementation_commit=MEASURED, final_verified_commit=MEASURED)
verification = baseline["integration_verification"]
verification["windows_full_source_verify"]["status"] = "passed"
verification["linux_installed_wheel_base_candidate"]["status"] = "passed"
verification["final_artifacts"].update(commit=MEASURED, status="complete",
                                        linux_wheels_status="passed", windows_source_status="passed")
for row in baseline["candidates"] + baseline["extra_work"]:
    row.update(implemented=True, complete_suite_status="passed",
               complete_suite_platforms=dict(linux_installed_wheels="passed", windows_source="passed"))


def set_value(path, value):
    def change(matrix, manifest):
        target = matrix
        for key in path[:-1]:
            target = target[key]
        target[path[-1]] = value
    return change


def change_manifest(matrix, manifest):
    manifest["implementation_commit"] = "b" * 40


def omit_candidate(matrix, manifest):
    matrix["candidates"].pop()


def duplicate_candidate(matrix, manifest):
    matrix["candidates"][1]["id"] = matrix["candidates"][0]["id"]


def later_documentation(matrix, manifest):
    matrix["documentation_commit"] = "b" * 40
    matrix["production_commit"] = "c" * 40


CASES = [
    ("complete_measured_pair", None, True),
    ("later_documentation_and_earlier_production_lineage", later_documentation, True),
    ("stale_manifest_commit", change_manifest, False),
    ("stale_matrix_commit", set_value(["implementation_commit"], "b" * 40), False),
    ("missing_final_verified_commit", set_value(["final_verified_commit"], None), False),
    ("wrong_final_artifact_commit", set_value(["integration_verification", "final_artifacts", "commit"], "b" * 40), False),
    ("pending_final_artifacts", set_value(["integration_verification", "final_artifacts", "status"], "pending"), False),
    ("pending_source_run", set_value(["integration_verification", "windows_full_source_verify", "status"], "pending"), False),
    ("pending_wheel_run", set_value(["integration_verification", "linux_installed_wheel_base_candidate", "status"], "pending"), False),
    ("pending_source_artifacts", set_value(["integration_verification", "final_artifacts", "windows_source_status"], "pending"), False),
    ("pending_wheel_artifacts", set_value(["integration_verification", "final_artifacts", "linux_wheels_status"], "pending"), False),
    ("unimplemented_candidate", set_value(["candidates", 0, "implemented"], False), False),
    ("unverified_candidate", set_value(["candidates", 0, "complete_suite_status"], "pending"), False),
    ("unverified_candidate_platform", set_value(["candidates", 0, "complete_suite_platforms", "windows_source"], "pending"), False),
    ("missing_candidate", omit_candidate, False),
    ("duplicate_candidate", duplicate_candidate, False),
    ("unimplemented_ci_extra", set_value(["extra_work", 0, "implemented"], False), False),
]
OUTPUT.mkdir(exist_ok=True)
results = []
with tempfile.TemporaryDirectory(prefix="metadata-", dir=OUTPUT) as temporary:
    private = Path(temporary)
    for name, change, expected in CASES:
        case = private / name
        case.mkdir()
        matrix = copy.deepcopy(baseline)
        manifest = dict(implementation_commit=MEASURED, entries=[])
        if change:
            change(matrix, manifest)
        (case / "completion-matrix.json").write_text(json.dumps(matrix), encoding="utf-8")
        (case / "report-draft.md").write_text("Measured report\n", encoding="utf-8")
        (case / "decisions.tsv").write_text("date\tdecision\n", encoding="utf-8")
        manifest["entries"] = [dict(path=path, sha256=hashlib.sha256((case / path).read_bytes()).hexdigest())
                               for path in ("report-draft.md", "completion-matrix.json", "decisions.tsv")]
        (case / "evidence-manifest.json").write_text(json.dumps(manifest), encoding="utf-8")
        failure = None
        try:
            with contextlib.redirect_stdout(io.StringIO()):
                module.package(case, private, case / "output", {"source_verdict": {"commit": MEASURED}})
            accepted = True
        except (AssertionError, KeyError, ValueError) as error:
            accepted, failure = False, f"{type(error).__name__}: {error}"
        results.append(dict(case=name, expected_accept=expected, accepted=accepted,
                            passed=accepted == expected, refusal=failure,
                            output_created=(case / "output").exists()))
receipt = dict(method="Call the real scratch package() seam with private synthetic metadata; do not call full source/wheel validation or alter repository state.",
               finalizer=str(FINALIZER), finalizer_sha256=hashlib.sha256(FINALIZER.read_bytes()).hexdigest(),
               cases=results, passed=sum(row["passed"] for row in results),
               failed=sum(not row["passed"] for row in results))
destination = OUTPUT / sys.argv[1]
destination.write_text(json.dumps(receipt, indent=2) + "\n", encoding="utf-8")
print(json.dumps(dict(receipt=str(destination), passed=receipt["passed"], failed=receipt["failed"])))
raise SystemExit(bool(receipt["failed"]))
