"""Preserve the completed 72b Windows refusal and Linux pass as attempt 4."""
import copy
import hashlib
import json
from pathlib import Path
import sqlite3
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
REPO = Path("C:/Users/jfgag/crapkit")
COMMIT = "72b1125d07904f8f41c465e4fe79aba2a1db5fa7"
ALIASES = {"wheels-final/": "wheels-attempt4/", "full-wheels-final.": "full-wheels-attempt4.",
           "final-wheel-proof.json": "wheel-attempt4-proof.json"}


def read(name):
    return json.loads((ROOT / name).read_text(encoding="utf-8-sig"))


def save(name, value):
    (ROOT / name).write_text(json.dumps(value, indent=2) + "\n", encoding="utf-8")


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def remap(value):
    if isinstance(value, dict):
        return {key: remap(item) for key, item in value.items()}
    if isinstance(value, list):
        return [remap(item) for item in value]
    if isinstance(value, str):
        for before, after in ALIASES.items():
            value = value.replace(before, after)
    return value


def suite(name):
    root = ET.parse(ROOT / "source-attempt4" / f"{name}.xml").getroot()
    cases = list(root.iter("testcase"))
    failed = [f"{case.get('classname')}::{case.get('name')}" for case in cases
              if case.find("failure") is not None or case.find("error") is not None]
    skipped = sum(case.find("skipped") is not None for case in cases)
    return dict(tests=len(cases), passed=len(cases) - len(failed) - skipped,
                skipped=skipped, failures=failed,
                junit_suite_seconds=sum(float(node.get("time", 0)) for node in root.iter("testsuite")))


result = read("source-attempt4/result.json")
verdict = read("source-attempt4/verdict.json")
linux = remap(read("wheel-attempt4-proof.json"))
assert result["commit"] == verdict["commit"] == linux["candidate_commit"] == COMMIT
assert result["exit"] == 8 and verdict["ok"] is False
assert verdict["run_id"] == 80 and verdict["committed_findings"] == len(verdict["new_failures"]) == 2
assert linux["candidate_ok"] is True and linux["process_exit"] == 0
assert not verdict["gate_violations"] and not verdict["ratchet_regressions"]
with sqlite3.connect((ROOT / "source-attempt4/crap.sqlite").as_uri() + "?mode=ro", uri=True) as db:
    db.row_factory = sqlite3.Row
    ledger = [dict(row) for row in db.execute(
        "SELECT id,commit_sha,kind,verdict_ok,findings FROM runs WHERE id IN (77,80) ORDER BY id")]
assert ledger[-1] == dict(id=80, commit_sha=COMMIT, kind="verify", verdict_ok=0, findings=2)
assert ledger[0]["verdict_ok"] == 1 and ledger[0]["findings"] == 0
suites = {name: suite(name) for name in ("unit", "e2e")}
assert set(suites["unit"]["failures"]) == set(verdict["new_failures"])
assert not suites["e2e"]["failures"]
assert suites["unit"]["passed"] == 3906 and suites["e2e"]["passed"] == 795
coverage = read("source-attempt4/py.json")
source_files = {path.replace("\\", "/"): facts for path, facts in coverage["files"].items()
                if path.replace("\\", "/").startswith("src/crapkit/")}
assert 317 in source_files["src/crapkit/procs.py"]["executed_lines"]
assert {54, 55}.issubset(source_files["src/crapkit/_process_owner.py"]["executed_lines"])
linux_missing = {(row["path"], row["line"]) for row in linux["diff_uncovered"]}
windows_missing = {(row["path"], row["line"]) for row in verdict["diff_uncovered"]}
shared = [dict(path=path, line=line) for path, line in sorted(linux_missing & windows_missing)]
assert len(shared) == 9 and len(windows_missing) == 10
proof = dict(
    schema=1, status="completed; refused two no-progress fixture cases", candidate_commit=COMMIT,
    result=result, verdict=verdict, ledger=ledger, suites=suites,
    pytest_summary_seconds=dict(unit=588.17, e2e=854.40),
    coverage=dict(sha256=digest(ROOT / "source-attempt4/py.json"),
                  total_report_files=len(coverage["files"]), selected_source_files=len(source_files),
                  selection="Exact src/crapkit/ prefix after host path-separator conversion.",
                  source_executed_lines=sum(len(item["executed_lines"]) for item in source_files.values()),
                  source_missing_lines=sum(len(item["missing_lines"]) for item in source_files.values()),
                  procs_317_executed=True, windows_job_lines_54_55_executed=True),
    cross_host=dict(linux_proof="wheel-attempt4-proof.json", shared_uncovered=shared,
                    windows_only_missing=[dict(path=p, line=n) for p, n in sorted(windows_missing - linux_missing)],
                    linux_only_missing=[dict(path=p, line=n) for p, n in sorted(linux_missing - windows_missing)]),
    inputs={name: dict(sha256=digest(ROOT / "source-attempt4" / name),
                       bytes=(ROOT / "source-attempt4" / name).stat().st_size)
            for name in ("result.json", "verdict.json", "unit.xml", "e2e.xml", "junit.xml", "crap.sqlite", "py.json")},
    limits=["Coverage is retained from a refusing run and does not turn that verdict into a pass.",
            "Nine guard/API/cleanup lines remain unmeasured on both hosts; no wrong behavior was observed.",
            "The original coverage JSON and consistent SQLite snapshot stay in preserved scratch. This compact proof records input hashes and relevant rows."])
save("source-attempt4-proof.json", proof)
linux["status"] = "Historical 72b Linux wheel verification passed; same-commit Windows run 80 refused two no-progress fixture cases."
linux["limits"][-1] = "The same-commit Windows run 80 refused two no-progress fixture cases. A later candidate and complete reruns await the reviewed test repair."

matrix = read("completion-matrix.json")
assert matrix["implementation_commit"] == COMMIT
verification = matrix["integration_verification"]
windows = verification["windows_full_source_verify"]
windows.pop("current_progress", None)
windows.update(status="refused", note="72b run 80 completed and refused two no-progress fixture cases. Reviewed test repair and the next candidate are pending.",
               fourth_attempt=dict(status=proof["status"], result=result, verdict=verdict, ledger=ledger,
                                   suites=suites, evidence="source-attempt4-proof.json"))
wheels = verification["linux_installed_wheel_base_candidate"]
wheels.pop("final_attempt", None)
wheels.update(status="passed", note="72b complete Linux comparison passed and is preserved as attempt 4; the same-commit Windows run refused.",
              fourth_attempt=linux)
verification["final_artifacts"].update(
    status="refused", windows_source="source-attempt4/", linux_wheels="wheels-attempt4/",
    windows_source_status="refused", linux_wheels_status="passed",
    note="72b is not a complete pass: Windows run 80 refused two fixture cases; Linux passed. Next candidate and complete reruns await repair.")
verification["next_candidate"] = dict(status="pending", commit=None,
                                       reason="Wait for the reviewed no-progress fixture repair and root's measured commit.")
old_aliases = matrix["artifact_path_aliases"]
by_commit = old_aliases.get("by_measured_commit", {
    "0009a6776f7e260046589954d98e035918f89439": old_aliases.get("aliases", {})})
by_commit[COMMIT] = ALIASES
matrix["artifact_path_aliases"] = dict(
    policy="Preserved attempt files moved without changing bytes. Resolve original internal locators by the proof's measured commit, not by a global final-path replacement.",
    by_measured_commit=by_commit)
for row in matrix["candidates"] + matrix["extra_work"]:
    row["complete_suite_platforms"]["windows_source"] = "refused"
save("completion-matrix.json", matrix)

disposition = read("coverage-disposition.json")
prior = remap(copy.deepcopy(disposition["final_reconciliation"]))
prior.update(status="72b coverage reconciled: Linux passed; Windows run 80 refused two fixture cases.",
             proof="wheel-attempt4-proof.json", windows_proof="source-attempt4-proof.json",
             windows=dict(verdict_ok=False, run_id=80, findings=2, unmarked_over_target=0,
                          uncovered_count=10, diff_uncovered=verdict["diff_uncovered"]), shared_uncovered=shared)
prior["new_launch_error_line"].update(
    classification="host-specific regression trigger; executed by Windows run 80", windows_executed=True,
    windows_evidence="source-attempt4-proof.json",
    reason="Windows run 80 executes the native OSError rethrow. Linux uses fixed /bin/sh and leaves this line unmeasured; the statement is cross-platform, not globally unreachable.")
prior["conclusion"] = "Nine guard/API/cleanup lines remain missing on both hosts. The three platform ownership lines are measured by the other host. Windows also measures OSError rethrow line 317. Linux retains three unchanged host-specific unmarked scores. No ratchet mark was added."
disposition.update(status="Completed 72b cross-host coverage reconciled; Windows refused two fixture cases; next full candidate pending",
                   prior_72b_reconciliation=prior, final_reconciliation=prior)
save("coverage-disposition.json", disposition)

review = read("integration-review.json")
review["current_verification"] = dict(commit=COMMIT, linux="passed", windows=dict(
    status=proof["status"], evidence="source-attempt4-proof.json", run_id=80, verdict_ok=False, findings=2,
    suites=suites))
review["pending"] = [
    "Finish and independently review the Windows no-progress fixture repair. Run 80 is preserved with two unit failures and a passing E2E phase.",
    "Record the next measured candidate and complete source/wheel reruns. Final packaging requires matching passing evidence and complete metadata."]
save("integration-review.json", review)

manifest = read("evidence-manifest.json")
refresh = {"coverage-disposition.json", "integration-review.json", "decisions.tsv"}
for entry in manifest["entries"]:
    entry["path"] = remap(entry["path"])
    path = REPO / entry["path"][5:] if entry["path"].startswith("repo:") else ROOT / entry["path"]
    if entry["path"] not in refresh:
        assert digest(path) == entry["sha256"], f"Preserved evidence changed: {entry['path']}"
    if entry["path"].startswith(("wheels-attempt4/", "full-wheels-attempt4.", "wheel-attempt4-proof.json")):
        entry["kind"] = "historical passing Linux attempt"
        entry["purpose"] = "72b Linux comparison passed; same-commit Windows run 80 refused. Original bytes retained."


def include(name, kind, purpose):
    path = ROOT / name
    entry = dict(path=name, candidates=["ALL"], kind=kind, purpose=purpose,
                 bytes=path.stat().st_size, sha256=digest(path))
    manifest["entries"] = [item for item in manifest["entries"] if item["path"] != name] + [entry]


include("coverage-disposition.json", "coverage disposition", "Both completed 72b host reports reconciled; refusing Windows verdict retained")
include("integration-review.json", "independent integration review", "Completed implementation review; next fixture repair and full candidate pending")
include("source-attempt4-proof.json", "historical source proof", "Run 80 refusal, trusted baseline 77, complete JUnit counts and compact cross-host coverage")
for name in ("unit.xml", "e2e.xml", "junit.xml", "result.json", "verdict.json", "lane-py.log", "stderr.txt"):
    include("source-attempt4/" + name, "historical full source run", "72b run 80 refused two unit fixture cases; complete E2E passed")
include("measurements/record_attempt4.py", "replay", "Reconcile preserved 72b source and wheel artifacts without reading later active outputs")
if any(item["path"] == "decisions.tsv" for item in manifest["entries"]):
    include("decisions.tsv", "decision log", "Root-owned implementation and verification chronology; refresh after later append")
manifest.update(integration_verification="72b complete Windows run 80 refused two unit fixture cases; E2E and Linux wheels passed. A new measured candidate awaits the reviewed repair.",
                artifact_path_aliases=matrix["artifact_path_aliases"])
manifest["curation"]["included"] = "Focused red/green evidence, complete preserved source/wheel attempts, compact ledger/source/coverage proofs, owner reviews, bounded benchmarks and repeatable probes."
manifest["curation"]["excluded"][-1] = "Future candidate artifacts are not yet available; no final complete pass is claimed."
manifest["entries"].sort(key=lambda item: item["path"])
manifest["curation"].update(file_count=len(manifest["entries"]), total_bytes=sum(item["bytes"] for item in manifest["entries"]))
save("evidence-manifest.json", manifest)
print(json.dumps(dict(commit=COMMIT, source_suites=suites, source_ledger=ledger[-1], linux="passed",
                      shared_gaps=len(shared), manifest_entries=len(manifest["entries"]),
                      manifest_bytes=manifest["curation"]["total_bytes"]), indent=2))
