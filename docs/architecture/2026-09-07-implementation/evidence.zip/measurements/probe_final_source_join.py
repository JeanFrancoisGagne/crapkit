"""Prove saved installed-runtime coverage cannot contribute to checkout scores."""
import hashlib
import inspect
import json
from pathlib import Path
import sqlite3
import tomllib

from crapkit import covstream, lanes, score
from crapkit.snapshot import InventoryRow

ROOT = Path(__file__).resolve().parents[1]
REPO = Path("C:/Users/jfgag/crapkit")
artifact = ROOT / "source-final/py.json"
config = tomllib.loads((REPO / "crapkit.toml").read_text(encoding="utf-8"))
lane = next(item for item in config["lane"] if item["name"] == "py")
assert lane["parser"] == "coveragepy" and lane["scopes"] == ["src"] and not lane.get("path_prefix", "")
coverage, checksum = covstream.parse_coveragepy_file(artifact, path_prefix="")
raw = json.loads(artifact.read_text(encoding="utf-8"))
assert set(coverage) == {name.replace("\\", "/") for name in raw["files"]}
source = {name: data for name, data in coverage.items() if name.startswith("src/crapkit/")}
outside = {name: data for name, data in coverage.items() if name not in source}
assert len(source) == 71 and len(outside) == 69 and not source.keys() & outside.keys()
sql = """SELECT i.scope,i.path,i.long_name,f.start,f.end,f.ccn_std,f.ccn_mod,f.ccn,
f.nloc,f.params,f.nesting,f.cognitive,f.occurrence,f.cov,f.crap
FROM functions f JOIN identities i ON i.id=f.identity_id
WHERE f.run_id=81 AND i.scope='src'
ORDER BY i.scope,i.path,f.start,f.occurrence,f.end,i.long_name"""
with sqlite3.connect((ROOT / "source-final/crap.sqlite").as_uri() + "?mode=ro", uri=True) as db:
    records = db.execute(sql).fetchall()
rows = [InventoryRow(*row[:13]) for row in records]
assert rows and {row.path for row in rows}.issubset(source)
full_scores = score.score_rows(rows, coverage, lane_scopes={"src"})
checkout_scores = score.score_rows(rows, source, lane_scopes={"src"})
outside_scores = score.score_rows(rows, outside, lane_scopes={"src"})
assert full_scores == checkout_scores
assert all((actual.cov, actual.crap) == tuple(saved[13:]) for actual, saved in zip(full_scores, records))
assert all(row.cov == 0 and row.flag == "untested" for row in outside_scores)
outside_execution = {name.replace("\\", "/"): len(data["executed_lines"])
                     for name, data in raw["files"].items() if name.replace("\\", "/") in outside}
evidence = dict(
    status="proved; installed-runtime keys cannot contribute to the saved checkout scores",
    commit="4ef04cab273629eae28755fccbfbd934aa098f7e", run_id=81, artifact_sha256=checksum,
    method="Read the saved artifact through the real coverage reader; reconstruct exact source inventory rows from read-only run81 SQLite; compare the real scorer with full, checkout-only and outside-only coverage maps.",
    reader_mapping="The lane has no path_prefix. The reader only converts backslashes to slashes; absolute installed-runtime keys remain absolute.",
    admission="The scope admission finds checkout keys under src and returns without rebasing any key. The scorer performs exact row.path lookup before comparing function spans.",
    counts=dict(raw_paths=len(coverage), checkout_paths=len(source), installed_runtime_paths=len(outside),
                installed_runtime_paths_with_executed_lines=sum(bool(count) for count in outside_execution.values()),
                installed_runtime_executed_line_entries=sum(outside_execution.values()), scored_checkout_rows=len(rows)),
    assertions=dict(no_key_overlap=True, full_equals_checkout_only=True, full_cov_and_crap_equal_saved_run81=True,
                    installed_only_scores_every_checkout_row_untested=True),
    score_vector_sha256=hashlib.sha256(json.dumps([list(row) for row in full_scores], separators=(",", ":")).encode()).hexdigest(),
    checkout_scored_paths=sorted({row.path for row in rows}),
    outside_paths=sorted(outside),
    source_references=[dict(path="src/crapkit/covstream.py", function="_Files.add", line=inspect.getsourcelines(covstream._Files.add)[1]),
                       dict(path="src/crapkit/lanes.py", function="_judge_artifact_scope", line=inspect.getsourcelines(lanes._judge_artifact_scope)[1]),
                       dict(path="src/crapkit/score.py", function="_span_join_cov", line=inspect.getsourcelines(score._span_join_cov)[1])],
    limits=["The Windows artifact contains installed-runtime execution; it is not described as exclusively checkout-source execution.",
            "This proves path separation and exact saved score reproduction. It does not infer why each test imported the installed runtime.",
            "The independently built Linux candidate wheel has 71 source paths and no outside coverage paths."])
(ROOT / "final-source-join-proof.json").write_text(json.dumps(evidence, indent=2) + "\n", encoding="utf-8")
print(json.dumps(dict(status=evidence["status"], counts=evidence["counts"], assertions=evidence["assertions"])))
