"""Same-interpreter duplication comparison, with immutable shared inputs."""
import argparse
import gc
import hashlib
import importlib.util
import json
from pathlib import Path
import statistics
import time
import tracemalloc

from crapkit.analyze import analyze_source
from crapkit.snapshot import InventoryRow, build_inventory_rows
import crapkit.dup as candidate

HERE = Path(__file__).resolve().parent
BASE = HERE / "base-source/src"


def baseline():
    spec = importlib.util.spec_from_file_location("crapkit._baseline_dup", BASE / "crapkit/dup.py")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def self_case():
    path = HERE / "duplication-self-input.json"
    if not path.exists():
        sources = {str(file.relative_to(BASE)).replace("\\", "/"): file.read_text(encoding="utf-8")
                   for file in sorted((BASE / "crapkit").rglob("*.py"))}
        records = [record for name, code in sources.items() for record in analyze_source(name, code)]
        rows = build_inventory_rows({"src": records})
        path.write_text(json.dumps({"rows": rows, "sources": sources}), encoding="utf-8")
    data = json.loads(path.read_text(encoding="utf-8"))
    return [InventoryRow(*row) for row in data["rows"]], data["sources"]


def clones(count):
    text = "def f():\n" + "\n".join(f"    line_{j} = compute({j})" for j in range(10))
    sources = {f"file-{i:04}.py": text for i in range(count)}
    rows = [InventoryRow("src", path, "f", 1, 11, 3, 3, 3, 11, 0, 0) for path in sources]
    return rows, sources


def measure(module, rows, sources, *, memory=False):
    gc.collect()
    if memory:
        tracemalloc.start()
    start = time.perf_counter()
    pairs = module.find_duplicates(rows, lambda: sources, top=1)
    seconds = time.perf_counter() - start
    peak = tracemalloc.get_traced_memory()[1] if memory else None
    if memory:
        tracemalloc.stop()
    return {"seconds": seconds, "peak_bytes": peak, "pairs": pairs}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("phase", choices=("before", "after"))
    args = parser.parse_args()
    modules = {"base": baseline()}
    if args.phase == "after":
        modules["candidate"] = candidate
    out = {"phase": args.phase, "base_source": str(BASE), "candidate_source": candidate.__file__, "cases": {}}
    for name, (rows, sources) in [("self", self_case()), ("clones300", clones(300)), ("clones600", clones(600))]:
        case = {"functions": len(rows), "source_bytes": sum(len(v.encode()) for v in sources.values()),
                "cold": {}, "warm": {key: [] for key in modules}, "memory": {}}
        for key, module in modules.items():
            case["cold"][key] = measure(module, rows, sources)
        for round_index in range(5):
            order = list(modules) if round_index % 2 == 0 else list(reversed(modules))
            for key in order:
                case["warm"][key].append(measure(modules[key], rows, sources))
        for key, module in modules.items():
            case["memory"][key] = measure(module, rows, sources, memory=True)
        case["median_seconds"] = {key: statistics.median(v["seconds"] for v in runs)
                                  for key, runs in case["warm"].items()}
        out["cases"][name] = case
    raw = (HERE / "duplication-self-input.json").read_bytes()
    out["self_input_sha256"] = hashlib.sha256(raw).hexdigest()
    (HERE / f"duplication-{args.phase}.json").write_text(json.dumps(out, indent=2), encoding="utf-8")
    print(json.dumps({name: {"median": value["median_seconds"], "peak": {
        key: measurement["peak_bytes"] for key, measurement in value["memory"].items()}}
        for name, value in out["cases"].items()}, indent=2))


if __name__ == "__main__":
    main()
