"""Compare ordinary export cost before changing the frozen record codec."""
import gc
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import statistics
import time

import crapkit.score as score
from crapkit.records import encode_record

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location("crapkit._baseline_score", HERE / "base-source/src/crapkit/score.py")
base = importlib.util.module_from_spec(spec)
spec.loader.exec_module(base)

BREAKS = re.compile(r"[\n\r\v\f\x1c-\x1e\x85\u2028\u2029]")
FORMAT = "\t".join(["%s"] * len(score.ScoredRow._fields))


def proposed_line(fields):
    line = FORMAT % tuple(fields)
    if line.startswith("#") or line.count("\t") != len(fields) - 1 or BREAKS.search(line):
        return "@crapkit-record-v1\t" + json.dumps(list(map(str, fields)), ensure_ascii=True, separators=(",", ":"))
    return line


def proposed(rows):
    yield "\t".join(score.ScoredRow._fields) + "\n"
    for row in rows:
        yield proposed_line(row) + "\n"


def measure(function, rows):
    gc.collect()
    start = time.perf_counter()
    text = "".join(function(rows))
    elapsed = time.perf_counter() - start
    return {"seconds": elapsed, "bytes": len(text), "sha256": hashlib.sha256(text.encode()).hexdigest()}


def main():
    rows = [score.ScoredRow("src", f"src/file-{index // 90}.py", f"work_{index}( value )", 1, 9,
                            3, 3, 3, 9, 1, 1, 0.5, "measured", 4.125, "ok", 1, 0)
            for index in range(140922)]
    functions = {"base": base.scored_tsv_lines, "current": score.scored_tsv_lines, "proposal": proposed}
    out = {"rows": len(rows), "source": score.__file__, "cold": {}, "warm": {key: [] for key in functions}}
    for key, function in functions.items():
        out["cold"][key] = measure(function, rows)
    for index in range(5):
        order = list(functions) if index % 2 == 0 else list(reversed(functions))
        for key in order:
            out["warm"][key].append(measure(functions[key], rows))
    out["median_seconds"] = {key: statistics.median(value["seconds"] for value in runs)
                              for key, runs in out["warm"].items()}
    (HERE / "records-benchmark.json").write_text(json.dumps(out, indent=2), encoding="utf-8")
    print(json.dumps(out["median_seconds"], indent=2))


if __name__ == "__main__":
    main()
