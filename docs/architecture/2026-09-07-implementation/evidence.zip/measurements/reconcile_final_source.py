"""Reconcile passing run81 and complete the final report metadata."""
import ast
import copy
import hashlib
import json
from pathlib import Path
import sqlite3
import subprocess
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
REPO = Path("C:/Users/jfgag/crapkit")
COMMIT = "4ef04cab273629eae28755fccbfbd934aa098f7e"
PRODUCTION = "0082379e350aa0eed44eeec50514023a573f61df"
RATCHET = "a30319ff0282306906d8da2df982084025f9e647d999b9e158697778214b03ac"


def read(name):
    return json.loads((ROOT / name).read_text(encoding="utf-8-sig"))


def save(name, value):
    (ROOT / name).write_text(json.dumps(value, indent=2) + "\n", encoding="utf-8")


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def suite(name):
    root = ET.parse(ROOT / "source-final" / f"{name}.xml").getroot()
    cases = list(root.iter("testcase"))
    failed = [f"{case.get('classname')}::{case.get('name')}" for case in cases
              if case.find("failure") is not None or case.find("error") is not None]
    skipped = sum(case.find("skipped") is not None for case in cases)
    return dict(tests=len(cases), passed=len(cases) - len(failed) - skipped,
                skipped=skipped, failures=failed,
                junit_suite_seconds=sum(float(node.get("time", 0)) for node in root.iter("testsuite")))


result = read("source-final/result.json")
verdict = read("source-final/verdict.json")
wheel = read("final-wheel-proof.json")
join = read("final-source-join-proof.json")
assert result["commit"] == verdict["commit"] == wheel["candidate_commit"] == join["commit"] == COMMIT
assert verdict["ok"] and result["exit"] == 0 and verdict["committed_findings"] == 0
assert wheel["candidate_ok"] and wheel["process_exit"] == 0
assert verdict["ratchet_sha256"] == wheel["ratchet_sha256"] == RATCHET
assert not verdict["new_failures"] and not verdict["gate_violations"] and not verdict["ratchet_regressions"]
with sqlite3.connect((ROOT / "source-final/crap.sqlite").as_uri() + "?mode=ro", uri=True) as db:
    db.row_factory = sqlite3.Row
    ledger = [dict(row) for row in db.execute(
        "SELECT id,commit_sha,kind,verdict_ok,findings FROM runs WHERE id IN (77,81) ORDER BY id")]
    windows_functions = [dict(row) for row in db.execute("""SELECT i.path,i.long_name,f.start,f.end,f.ccn,f.cov,f.crap
        FROM functions f JOIN identities i ON i.id=f.identity_id
        WHERE f.run_id=81 AND i.path='src/crapkit/procs.py'
        AND (i.long_name LIKE '_windows_arguments(%' OR i.long_name LIKE '_multiline_mode(%' OR i.long_name LIKE 'prepare_template(%')""")]
assert ledger[-1] == dict(id=81, commit_sha=COMMIT, kind="verify", verdict_ok=1, findings=0)
assert ledger[0] == dict(id=77, commit_sha="b11e2c165411b5ff9caa6b4b8486aafe477dfeb8", kind="verify", verdict_ok=1, findings=0)
assert len(windows_functions) == 3 and all(row["cov"] == 1 for row in windows_functions)
suites = {name: suite(name) for name in ("unit", "e2e")}
assert not any(item["failures"] for item in suites.values())
assert suites["unit"]["passed"] == 3912 and suites["e2e"]["passed"] == 795
assert suites["unit"]["skipped"] == 3 and suites["e2e"]["skipped"] == 6
coverage = read("source-final/py.json")
source_files = {path.replace("\\", "/"): facts for path, facts in coverage["files"].items()
                if path.replace("\\", "/").startswith("src/crapkit/")}
assert 317 in source_files["src/crapkit/procs.py"]["executed_lines"]
assert {54, 55}.issubset(source_files["src/crapkit/_process_owner.py"]["executed_lines"])
assert all(join["assertions"].values()) and join["artifact_sha256"] == digest(ROOT / "source-final/py.json")
subprocess.run(["git", "diff", "--exit-code", PRODUCTION, COMMIT, "--", "src/crapkit"], cwd=REPO, check=True, capture_output=True)
state = subprocess.check_output(["git", "status", "--porcelain=v1", "-z", "--untracked-files=all", "--", "src/crapkit"], cwd=REPO)
assert not state
subprocess.run(["git", "diff", "--exit-code", COMMIT, "--", "src/crapkit"], cwd=REPO, check=True, capture_output=True)
linux_missing = {(row["path"], row["line"]) for row in wheel["diff_uncovered"]}
windows_missing = {(row["path"], row["line"]) for row in verdict["diff_uncovered"]}
shared = [dict(path=path, line=line) for path, line in sorted(linux_missing & windows_missing)]
assert len(shared) == 9 and len(windows_missing) == 10 and len(linux_missing) == 12
proof = dict(
    schema=1, status="complete; Windows source verification passed", measured_commit=COMMIT,
    production_bytes_unchanged_since=PRODUCTION, result=result, verdict=verdict, ledger=ledger, suites=suites,
    pytest_summary_seconds=dict(unit=820.06, e2e=995.69),
    invocation=dict(python=result["python"], pythonpath=str(REPO / "src"),
                    command="python -m crapkit verify --no-tighten --base c2d3515581d410d8c14849063dac27af843a3729 --json",
                    replay="run-source-final.ps1", trusted_baseline_run=77),
    source_identity=dict(wheel_proof="final-wheel-proof.json", python_source_files=71,
                         candidate_git_blobs_match_installed_wheel=True, local_package_source_clean=True,
                         local_source_diff_from_measured_commit_empty=True, production_diff_from_0082379_empty=True),
    coverage=dict(sha256=digest(ROOT / "source-final/py.json"), populations=join["counts"],
                  population_proof="final-source-join-proof.json", source_executed_lines=sum(len(item["executed_lines"]) for item in source_files.values()),
                  source_missing_lines=sum(len(item["missing_lines"]) for item in source_files.values()),
                  procs_317_executed=True, windows_job_lines_54_55_executed=True),
    windows_counterparts_of_linux_unmarked=windows_functions,
    cross_host=dict(linux_proof="final-wheel-proof.json", shared_uncovered=shared,
                    windows_only_missing=[dict(path=p, line=n) for p, n in sorted(windows_missing - linux_missing)],
                    linux_only_missing=[dict(path=p, line=n) for p, n in sorted(linux_missing - windows_missing)]),
    inputs={name: dict(sha256=digest(ROOT / "source-final" / name), bytes=(ROOT / "source-final" / name).stat().st_size)
            for name in ("result.json", "verdict.json", "unit.xml", "e2e.xml", "junit.xml", "crap.sqlite", "py.json")},
    limits=["Windows source coverage includes separate installed-runtime paths. The real reader/scorer probe proves they cannot contribute to checkout scores.",
            "Nine guard/API/cleanup lines remain unmeasured on both hosts; no wrong behavior was observed.",
            "No raw coverage JSON or SQLite copy is added to the curated archive; compact proofs retain hashes and relevant rows.",
            "macOS and hosted CI/Action dispatch were not executed."])
save("final-source-proof.json", proof)
wheel["status"] = "Linux wheel verification passed; matching Windows run81 also passed"
wheel["limits"][-1] = "Matching Windows source run81 passed. Its separate source and population proofs are final-source-proof.json and final-source-join-proof.json."
save("final-wheel-proof.json", wheel)

disposition = read("coverage-disposition.json")
if "historical_first_attempt" not in disposition:
    disposition["historical_first_attempt"] = {key: copy.deepcopy(disposition[key]) for key in (
        "measured_commit", "method", "evidence", "unmarked_over_target", "changed_line_summary", "changed_line_groups")}
groups = copy.deepcopy(disposition["historical_first_attempt"]["changed_line_groups"])
for group in groups:
    if group["path"] == "src/crapkit/procs.py":
        group.update(function="_complete_command", measured_start=320,
                     linux_missing_lines=[327, 328, 329], windows_missing_lines=[327, 328, 329])
    group["measured_commit"] = COMMIT
    group.pop("final_anchor", None)
    if group["function"] != "SourcePatch.result":
        tree = ast.parse((REPO / group["path"]).read_text(encoding="utf-8"))
        node = next(item for item in ast.walk(tree) if isinstance(item, ast.FunctionDef) and item.name == group["function"])
        group.update(measured_start=node.lineno, measured_end=node.end_lineno)
groups.append(dict(path="src/crapkit/procs.py", function="_raise_launch_error", measured_commit=COMMIT,
                   measured_start=307, measured_end=317, linux_missing_lines=[317], windows_missing_lines=[],
                   classification="host-specific regression trigger; measured by Windows",
                   trigger="A native shell-launch OSError is transported back after cleanup; the existing missing-COMSPEC regression triggers it on Windows.",
                   evidence="Windows run81 executes line317. Linux uses fixed /bin/sh and leaves the same cross-platform statement unmeasured.",
                   disposition="Covered on Windows; not globally unreachable."))
windows_by_name = {row["long_name"]: row for row in windows_functions}
unmarked_functions = []
for row in wheel["unmarked_over_target"]:
    current = copy.deepcopy(row)
    current.update(windows_cov=windows_by_name[row["long_name"]]["cov"], windows_crap=windows_by_name[row["long_name"]]["crap"],
                   base_linux_measurement_unchanged=True, body_unchanged_from_base=True, has_ratchet_mark=False)
    unmarked_functions.append(current)
disposition.update(
    status="complete; final Windows source and Linux installed-wheel coverage reconciled",
    measured_commit=COMMIT, latest_committed_candidate_commit=COMMIT,
    method="Read-only saved run81/run2 ledgers, exact current Git source identity, actual final JUnit and coverage, and real scorer equivalence for separate Windows coverage populations.",
    evidence=dict(source_proof="final-source-proof.json", wheel_proof="final-wheel-proof.json", population_proof="final-source-join-proof.json",
                  source_verdict="source-final/verdict.json", source_sqlite="source-final/crap.sqlite", source_coverage="source-final/py.json",
                  linux_verdict="wheels-final/verdict.json", linux_attempt=wheel["attempt"],
                  replay=["measurements/reconcile_final_source.py", "measurements/probe_final_source_join.py"]),
    unmarked_over_target=dict(linux_count=3, windows_count=0, functions=unmarked_functions,
                             disposition="All three helpers retain unchanged base Linux scores and complete final Windows coverage. No ratchet marks were added."),
    changed_line_summary=dict(linux_missing=12, windows_missing=10, shared_missing=9,
                              linux_platform_only=2, linux_host_trigger=1, windows_platform_only=1,
                              classification="Nine guard/API/cleanup lines remain unmeasured on both hosts. Windows measures both Job lines and native OSError rethrow; Linux measures the POSIX process-group line."),
    changed_line_groups=groups,
    final_reconciliation=dict(status="complete; both hosts passed", commit=COMMIT,
                              source_proof="final-source-proof.json", wheel_proof="final-wheel-proof.json",
                              windows=dict(run_id=81, verdict_ok=True, findings=0, uncovered_count=10, unmarked_over_target=0),
                              linux=dict(run_id=2, verdict_ok=True, findings=0, uncovered_count=12, unmarked_over_target=3),
                              shared_uncovered=shared,
                              rules=["Keep host populations and ledgers separate.", "Retain nine measured guard/API/cleanup gaps and the named parse_scored_row compatibility API.",
                                     "No ratchet marks or coverage gates were changed to conceal these diagnostics."]))
save("coverage-disposition.json", disposition)

matrix = read("completion-matrix.json")
matrix.update(implementation_commit=COMMIT, final_verified_commit=COMMIT,
              canonical_report_path="docs/architecture/2026-09-07-implementation/REPORT.md")
for row in matrix["candidates"] + matrix["extra_work"]:
    row.update(status="complete; focused and full checks passed", implemented=True, complete_suite_status="passed",
               complete_suite_platforms=dict(linux_installed_wheels="passed", windows_source="passed"))
for repair in matrix["integration_followups"]:
    repair["status"] = "committed; focused checks and final complete runs passed"
verification = matrix["integration_verification"]
windows = verification["windows_full_source_verify"]
windows.pop("current_progress", None)
windows.update(status="passed", note="Complete run81 passed at the measured4ef commit; saved ledger matches and trusted baseline77 remains passing.", final_attempt=proof)
verification["linux_installed_wheel_base_candidate"].update(status="passed", note="Complete candidate wheel suites and comparison passed at the same4ef commit; actual historical base failures remain recorded.", final_attempt=wheel)
verification["final_artifacts"].update(commit=COMMIT, status="complete", windows_source_status="passed", linux_wheels_status="passed",
                                      note="Both complete runs passed at4ef. Production bytes remain unchanged from0082379; later documentation commits do not change the measured revision.")
save("completion-matrix.json", matrix)

integration = read("integration-review.json")
integration.update(status="complete; implementation reviews and both measured full runs passed",
                   current_verification=dict(commit=COMMIT, windows="passed", linux="passed",
                                             source_proof="final-source-proof.json", linux_proof="final-wheel-proof.json"), pending=[])
integration["manifest_finalizer_review"]["coverage_population_admission"] = "final-source-join-proof.json"
save("integration-review.json", integration)

manifest = read("evidence-manifest.json")
refresh = {"final-wheel-proof.json", "coverage-disposition.json", "integration-review.json"}
for entry in manifest["entries"]:
    path = REPO / entry["path"][5:] if entry["path"].startswith("repo:") else ROOT / entry["path"]
    if entry["path"] not in refresh:
        assert digest(path) == entry["sha256"], f"Preserved evidence changed: {entry['path']}"


def include(name, kind, purpose):
    path = ROOT / name
    entry = dict(path=name, candidates=["ALL"], kind=kind, purpose=purpose,
                 bytes=path.stat().st_size, sha256=digest(path))
    manifest["entries"] = [item for item in manifest["entries"] if item["path"] != name] + [entry]


for name in ("unit.xml", "e2e.xml", "junit.xml", "result.json", "verdict.json", "lane-py.log", "stderr.txt"):
    include("source-final/" + name, "complete Windows source evidence", "Run81 passed at4ef; original complete JUnit, verdict, result and logs")
for name in ("final-source-proof.json", "final-source-join-proof.json", "final-wheel-proof.json"):
    include(name, "complete measured proof", "Exact final verdict/ledger/source/coverage reconciliation with distinct populations")
include("coverage-disposition.json", "final coverage disposition", "Primary facts at4ef; nine shared gaps retained and earlier attempts named as history")
include("integration-review.json", "final integration review", "Closed findings and matching passing full runs; no current pending review")
include("measurements/reconcile_final_source.py", "replay", "Reconcile saved Windows run81, current coverage and final completion metadata")
include("measurements/probe_final_source_join.py", "replay", "Prove installed-runtime coverage keys cannot affect1709 checkout scores")
include("check_package.py", "archive check", "Check actual archive CRC, internal manifest hashes, unique members and matching measured verdicts")
manifest.update(implementation_commit=COMMIT, integration_verification="Complete Windows source and Linux installed-wheel verification passed at4ef04cab; saved ledgers agree.")
manifest["curation"]["excluded"] = ["Temporary Git repositories, worktrees and runtime environments",
    "Raw coverage databases, consistent SQLite snapshots and large source coverage JSON files; compact proofs retain exact hashes and relevant rows",
    "Repeated full-coverage benchmark payloads; compact summaries and replay scripts remain", "Obsolete setup files and transient scratch outputs"]
manifest["entries"].sort(key=lambda item: item["path"])
manifest["curation"].update(file_count=len(manifest["entries"]), total_bytes=sum(item["bytes"] for item in manifest["entries"]))
save("evidence-manifest.json", manifest)
print(json.dumps(dict(commit=COMMIT, source_suites=suites, ledger=ledger, shared_gaps=9,
                      candidates_complete=len(matrix["candidates"]), extra_complete=len(matrix["extra_work"]),
                      entries=len(manifest["entries"]), bytes=manifest["curation"]["total_bytes"]), indent=2))
