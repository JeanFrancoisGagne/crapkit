"""Index the reviewed progress fixtures and mark 4ef full verification pending."""
import hashlib
import json
from pathlib import Path
import subprocess

ROOT = Path(__file__).resolve().parents[1]
REPO = Path("C:/Users/jfgag/crapkit")
COMMIT = "4ef04cab273629eae28755fccbfbd934aa098f7e"


def read(name):
    return json.loads((ROOT / name).read_text(encoding="utf-8-sig"))


def save(name, value):
    (ROOT / name).write_text(json.dumps(value, indent=2) + "\n", encoding="utf-8")


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


result = read("tests-ci/progress-deadline/result.json")
review = read("execution/progress-deadline-review.json")
assert result["hook"]["exit_code"] == 0
assert review["final_review"]["findings"] == []
for label in ("green", "posix"):
    assert len(result["runs"][label]) == 20
    assert all(not item["failed"] and not item["error"] and not item["skipped"] for item in result["runs"][label])
for label in ("red", "family-red", "watch-negative"):
    assert len(result["runs"][label]) == 2 and all(item["failed"] for item in result["runs"][label])
subprocess.run(["git", "diff", "--exit-code", "0082379e350aa0eed44eeec50514023a573f61df", COMMIT,
                "--", "src/crapkit"], cwd=REPO, check=True, capture_output=True)
matrix = read("completion-matrix.json")
matrix.update(implementation_commit=COMMIT, final_verified_commit=None)
verification = matrix["integration_verification"]
verification["windows_full_source_verify"].update(status="pending", note="4ef04cab complete source run pending; prior 72b run 80 refused two fixture cases.")
verification["linux_installed_wheel_base_candidate"].update(status="pending", note="4ef04cab complete fresh-wheel comparison pending; 72b Linux pass remains preserved as attempt 4.")
verification.pop("next_candidate", None)
verification["final_artifacts"].update(
    commit=COMMIT, last_committed_candidate=COMMIT, status="pending",
    windows_source="source-final/", linux_wheels="wheels-final/",
    windows_source_status="pending", linux_wheels_status="pending", pending_test_changes=[],
    note="Both complete runs are pending at 4ef04cab. The reviewed progress fixture repair changes two test files; production bytes equal 0082379.")
for row in matrix["candidates"] + matrix["extra_work"]:
    row.update(implemented=True, complete_suite_status="pending",
               complete_suite_platforms=dict(linux_installed_wheels="pending", windows_source="pending"))
repair = dict(
    id="INTEGRATION-PROGRESS-FIXTURES", candidates=["EX1", "CI-OPT"], commit=COMMIT,
    status="committed; 20 focused cases pass on each host; complete reruns pending",
    behavior="Establish real child readiness before unchanged cleanup waits. Use module-local controlled time and real file growth for periodic progress, exact idle expiry and total deadline precedence. Keep unwrapped real startup-silence and total-deadline controls.",
    files=result["changed_files"], production_changed=False, max_changed_function_ccn=4,
    evidence=["tests-ci/progress-deadline/result.json", "tests-ci/progress-deadline/green.xml",
              "tests-ci/progress-deadline/posix.xml", "execution/progress-deadline-review.json"],
    red="Two original failures plus two related cleanup fixtures fail with delayed startup.",
    green="20 passed on each host, identical IDs, no failures/errors/skips.",
    negative_control="Tests fail when growth no longer resets the idle clock or the total deadline is disabled.",
    measured_tradeoff="No latency gain claimed. Controlled-clock checks measure watcher rules; real subprocess checks retain output, errors and descendant cleanup.")
matrix["integration_followups"] = [item for item in matrix["integration_followups"] if item["id"] != repair["id"]] + [repair]
matrix["progress_deadline_review"] = dict(status="complete; no findings", evidence="execution/progress-deadline-review.json")
save("completion-matrix.json", matrix)

disposition = read("coverage-disposition.json")
rules = disposition["final_reconciliation"].get("rules", [])
disposition.update(status="Prior 72b coverage reconciled; both 4ef04cab full runs pending",
                   latest_committed_candidate_commit=COMMIT,
                   final_reconciliation=dict(status="pending", commit=COMMIT, linux_status="pending", windows_status="pending",
                                             historical_proof="source-attempt4-proof.json", rules=rules))
save("coverage-disposition.json", disposition)

integration = read("integration-review.json")
integration["status"] = "Implementation, fixture and packaging reviews complete; both 4ef04cab full runs pending."
integration["current_verification"] = dict(commit=COMMIT, windows="pending", linux="pending",
                                          prior_windows="source-attempt4-proof.json", prior_linux="wheel-attempt4-proof.json")
problem = "No-progress and cleanup fixtures assumed covered child startup and periodic writes fit inside short production deadlines"
integration["findings_closed"] = [item for item in integration["findings_closed"] if item["problem"] != problem] + [dict(
    problem=problem, fix=repair["behavior"],
    evidence=["tests-ci/progress-deadline/result.json", "execution/progress-deadline-review.json"])]
integration["pending"] = ["Complete both 4ef04cab source/wheel runs, reconcile their saved ledgers and coverage, then admit final report metadata and package only matching passing results."]
save("integration-review.json", integration)

manifest = read("evidence-manifest.json")
refresh = {"coverage-disposition.json", "integration-review.json", "decisions.tsv", "measurements/record_final_linux.py"}
for entry in manifest["entries"]:
    path = REPO / entry["path"][5:] if entry["path"].startswith("repo:") else ROOT / entry["path"]
    if entry["path"] not in refresh:
        assert digest(path) == entry["sha256"], f"Preserved evidence changed: {entry['path']}"


def include(name, kind, purpose):
    path = ROOT / name
    entry = dict(path=name, candidates=["EX1", "CI-OPT"], kind=kind, purpose=purpose,
                 bytes=path.stat().st_size, sha256=digest(path))
    manifest["entries"] = [item for item in manifest["entries"] if item["path"] != name] + [entry]


for name in ("result.json", "progress-deadline.patch", "red.xml", "red.log", "family-red.xml", "family-red.log",
             "green.xml", "green.log", "posix.xml", "posix.log", "precommit.log", "complexity.json",
             "watch-negative.xml", "watch-negative.log", "watch_negative.py", "record.py", "posix-check.sh",
             "before-test_init_probe.py", "before-test_procs.py", "green-test_init_probe.py", "green-test_procs.py",
             "red-family-test.py", "red-init-test.py", "red-test.py"):
    include("tests-ci/progress-deadline/" + name, "progress fixture repair", "Delayed-start red, 20 passing cases per host and negative controls for watcher rules")
include("execution/progress-deadline-review.json", "independent review", "Final fixture repair has no findings; deadline and cleanup assertions remain")
include("execution/progress-deadline-full-failures.txt", "historical full-run failures", "72b unit-phase traces underlying the two fixture repairs")
include("coverage-disposition.json", "coverage disposition", "Prior 72b host coverage retained; current 4ef full coverage pending")
include("integration-review.json", "independent integration review", "Fixture repair reviewed; only current complete runs and final packaging pending")
include("measurements/record_progress_candidate.py", "replay", "Index repaired fixtures and reset full-run fields to pending for the measured 4ef commit")
include("measurements/record_final_linux.py", "replay", "Index a passing wheel result using its actual measured commit")
if any(item["path"] == "decisions.tsv" for item in manifest["entries"]):
    include("decisions.tsv", "decision log", "Root-owned chronology; refreshed after the new candidate and run entries")
manifest.update(implementation_commit=COMMIT,
                integration_verification="Both 4ef04cab full runs pending. Complete 72b Windows refusal and Linux pass are preserved as attempt 4.")
manifest["curation"]["excluded"][-1] = "Active 4ef04cab source/wheel artifacts require their completed results."
manifest["entries"].sort(key=lambda item: item["path"])
manifest["curation"].update(file_count=len(manifest["entries"]), total_bytes=sum(item["bytes"] for item in manifest["entries"]))
save("evidence-manifest.json", manifest)
print(json.dumps(dict(commit=COMMIT, source="pending", wheels="pending", focused_green_per_host=20,
                      manifest_entries=len(manifest["entries"]), manifest_bytes=manifest["curation"]["total_bytes"])))
