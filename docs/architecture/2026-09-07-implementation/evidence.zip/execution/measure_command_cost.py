"""Interleaved command-lifetime cost with one interpreter and command."""
import json
import os
from pathlib import Path
import statistics
import subprocess
import sys

HERE = Path(__file__).resolve().parent
BASE = HERE / 'base-source' / 'src'
CANDIDATE = Path('C:/Users/jfgag/Documents/Codex/worktrees/ck-r2-execution/src')
CASE = '''import json,sys,time
from crapkit.procs import run_bounded,own_processes
command = f'"{sys._base_executable}" -I -S -c "pass"'
start = time.perf_counter()
if sys.argv[1] == "shared":
    with own_processes([]) as owner:
        ready = time.perf_counter()
        assert run_bounded(command, None, owner=owner) == 0
        elapsed = time.perf_counter() - ready
else:
    assert run_bounded(command, None) == 0
    elapsed = time.perf_counter() - start
print(json.dumps({"seconds":elapsed,"source":__import__("crapkit").__file__}))
'''

def sample(source, mode):
    environment = {key: value for key, value in os.environ.items()
                   if not key.startswith(('COVERAGE_', 'COV_CORE_'))}
    environment.update(PYTHONPATH=str(source), PYTHONDONTWRITEBYTECODE='1')
    result = subprocess.run([sys.executable, '-B', '-c', CASE, mode],
                            env=environment, capture_output=True, text=True, check=True)
    return json.loads(result.stdout)

data = {'interpreter': sys.executable, 'modes': {}}
for mode in ('standalone', 'shared'):
    pairs = [{name: sample(source, mode) for name, source in (('base', BASE), ('candidate', CANDIDATE))}
             for _ in range(6)]
    data['modes'][mode] = {'cold': pairs[0], 'warm': pairs[1:],
                          'warm_medians': {name: statistics.median(pair[name]['seconds'] for pair in pairs[1:])
                                           for name in ('base', 'candidate')}}
(HERE / 'command-cost.json').write_text(json.dumps(data, indent=2), encoding='utf-8')
print(json.dumps({mode: values['warm_medians'] for mode, values in data['modes'].items()}, indent=2))
