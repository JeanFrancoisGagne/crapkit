"""Record the target-only coverage isolation decision and root report check."""
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
root_report = HERE.parent / 'procs-fixture-cov-posix.json'
report = json.loads(root_report.read_text(encoding='utf-8'))
paths = report['files']
real = {name: {'executed_lines': len(row['executed_lines']),
               'executed_branches': len(row.get('executed_branches', []))}
        for name, row in paths.items()
        if name.endswith(('crapkit/procs.py', 'crapkit/_process_owner.py'))}
unexpected = [name for name in paths if not name.replace('\\', '/').startswith('src/crapkit/')]
assert len(real) == 2 and all(row['executed_lines'] > 0 for row in real.values()), real
assert not unexpected, unexpected
result = {
    'decision': '-S is sufficient for this deliberately fake target package.',
    'mechanism': 'coverage 7.16 patch=subprocess sets COVERAGE_PROCESS_CONFIG. Its installed .pth hook starts child coverage during site initialization. Target-only -S skips that hook while retaining PYTHONPATH. Parent and owner keep normal startup and measurement.',
    'root_focused_report': {'path': str(root_report), 'real_files': real, 'unexpected_paths': unexpected},
    'paired_probes': {host: str(HERE / ('fake-target-' + host + '-result.json'))
                      for host in ('windows', 'posix')},
    'observations': [
        'On each host, plain Python imports the fake package and removing its source makes coverage export exit 1.',
        'On each host, target-only -S preserves target package output, leaves no fake path in combined coverage, and makes export exit 0.',
        'Executed line counts for the real parent procs module and owner module are identical before and after adding -S on each host.',
        'The current root POSIX focused report contains only src/crapkit paths and measures both real modules.',
    ],
    'scope': 'This fixture imports only its fake package and standard-library code. No broad environment change or coverage exclusion is needed.',
    'alternative_if_site_is_required': 'Supply a copied target env without COVERAGE_PROCESS_CONFIG and COVERAGE_PROCESS_START to run_bounded. Keep the parent environment unchanged so the owner stays measured. This alternative was not needed or tested here.',
}
(HERE / 'fake-target-isolation-review.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
print(json.dumps(result['root_focused_report'], indent=2))
